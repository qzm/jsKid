function global() {

}